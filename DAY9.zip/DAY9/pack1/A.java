package pack1;
public class A{
	public void display(){
		System.out.println("A is called");
	}
}
