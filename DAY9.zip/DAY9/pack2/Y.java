package pack2;
public class Y{
	public void show(){
		System.out.println("Y is called");
	}
}
