package pack2;
public class X{
	public void show(){
		System.out.println("X is called");
	}
}
