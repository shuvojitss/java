import pack1.A;
import pack1.B;
import pack2.X;
import pack2.Y;
class Main{
	public static void main(String args[]){
		A ob1 = new A();
		ob1.display();
		B ob2 = new B();
		ob2.display();
		X ob3 = new X();
		ob3.show();
		Y ob4 = new Y();
		ob4.show();

	}
}