package pack1;
public class B{
	public void display(){
		System.out.println("B is called");
	}
}
